@extends('layouts.app')
@section('css')
@show
@section('content')

<body>
    @section('judulmain','Jadwal')
    <!-- ini untuk judul page nya , bisa di modifikasi -->
    @section('isimain')
    <!-- ini untuk isi content atlet nya , sampai endsection ya -->
    <div class="container">
        <h2 align="center" style="margin: 30px;"> Buat Jadwal </h2>
        <form class="form-data" id="form-data" action="/Data-Jadwal/create" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>PIC</label>
                        <input type="hidden" name="id" id="id">
                        <input type="text" name="PIC" id="jadwal_keberangkatan_atlit" class="form-control" required="true">
                        <p class="text-danger" id="err_PIC"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>list_atlit</label>
                        <input type="text" name="list_atlit" id="list_atlit" class="form-control" required="true">
                        <p class="text-danger" id="err_list_atlit"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Tiket_Pesawat</label>
                        <input type="text" name="Tiket_Pesawat" id="Tiket_Pesawat" class="form-control" required="true">
                        <p class="text-danger" id="err_Tiket_Pesawat"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Tanggal_keberangkatan</label>
                        <input type="date" name="Tanggal_keberangkatan" id="Tanggal_keberangkatan" class="form-control" required="true">
                        <p class="text-danger" id="err_Tanggal_keberangkatan"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Tanggal_kepulangan</label>
                        <input type="date" name="Tanggal_kepulangan" id="Tanggal_kepulangan" class="form-control" required="true">
                        <p class="text-danger" id="err_Tanggal_kepulangan"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Penginapan</label>
                        <input type="text" name="Penginapan" id="Penginapan" class="form-control" required="true">
                        <p class="text-danger" id="err_Penginapan"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Tempat_Pertandingan</label>
                        <input type="text" name="Tempat_Pertandingan" id="Tempat_Pertandingan" class="form-control" required="true">
                        <p class="text-danger" id="err_Tempat_Pertandingan"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Inventaris_mobil</label>
                        <input type="text" name="Inventaris_mobil" id="Inventaris_mobil" class="form-control" required="true">
                        <p class="text-danger" id="err_Inventaris_mobil"></p>
                    </div>
                </div>

                <button type="submit" name="simpan" id="simpan" class="btn btn-primary">
                    <i class="fa fa-save"></i> Simpan
                </button>
            </div>
        </form>
        <hr>

        <div class="data"></div>
    </div>
    <div class="text-center">© <?php echo date('d/m/Y'); ?> Copyright:

        @endsection

        <!-- NOTE: tinggal atur lagi aja css nya ya , biar engga ketabrak hehehe -->