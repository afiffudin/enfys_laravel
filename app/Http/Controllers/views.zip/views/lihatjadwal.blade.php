@extends('layouts.app')
@section('isimain')
<style>
    .foto_ktp {
        border-radius: 5px;
        width: 80px;
        height: 50px;
    }
</style>
<section class="content">
    <a href="#" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i><span> Add New Data </span></a>
    <a href="#" class="btn btn-warning" data-toggle="modal"><i class="fa fa-filter"></i><span> Filter Data By column</span></a>

    <div class="table-container">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>PIC</th>
                    <th>list atlit</th>
                    <th>Tiket_Pesawat</th>
                    <th>Tanggal_keberangkatan</th>
                    <th>Tanggal_kepulangan</th>
                    <th>Penginapan</th>
                    <th>Tempat_Pertandingan</th>
                    <th>Inventaris_mobil</th>
                </tr>
            </thead>
            <tbody>
                @foreach($lihatjadwal as $key=>$row)
                <tr>
                    <td>{{$row->id}}</td>
                    <td>{{$row->PIC}}</td>
                    <td>{{$row->list_atlit}}</td>
                    <td>{{$row->Tiket_Pesawat}}</td>
                    <td>{{$row->Tanggal_keberangkatan}}</td>
                    <td>{{$row->Tanggal_kepulangan}}</td>
                    <td>{{$row->Penginapan}}</td>
                    <td>{{$row->Tempat_Pertandingan}}</td>
                    <td>{{$row->Inventaris_mobil}}</td>
                    <td>
                        <a href="{{url ('/Data-Atlet/edit/'.$row->id)}}">
                            <button type="edit" class="btn btn-primary btn-md dt-edit">
                                <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                            </button>
                        </a>
                        <a href="{{url ('/Data-Atlet/delete/'.$row->id)}}">
                            <button type="delete" class="btn btn-danger btn-md dt-delete">
                                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                            </button>
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="text-center">© <?php echo date('d/m/Y'); ?> Copyright:</div>

</section>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script>
    $(document).ready(function() {
        $('a.more').click(function() {
            // Toggle Class
            $tr = $(this).parent().parent();
            $tr.toggleClass('expanded');
            // Tampilkan - sembunyikan baris
            $i = $(this).children('i');
            $i.removeClass('fa-chevron-down', 'fa-chevron-up');
            var arrow = $tr.hasClass('expanded') ? 'fa-chevron-up' : 'fa-chevron-down';
            $i.addClass(arrow);
            return false;
        });
    })
</script>
<script>
    @endsection