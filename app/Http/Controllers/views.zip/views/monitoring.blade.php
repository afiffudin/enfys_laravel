@extends('layouts.app')
@section('css')
@show
@section('content')

<body>
    @section('judulmain','monitoring')
    <!-- ini untuk judul page nya , bisa di modifikasi -->
    @section('isimain')
    <!-- ini untuk isi content atlet nya , sampai endsection ya -->
    <div class="container">
        <h2 align="center" style="margin: 30px;"> DATA MONITORING </h2>
        <div class="modal-body">
            <form class="form-data" id="form-data" action="/Data-monitoring/create" method="post">
                {{ csrf_field() }}
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>jadwal_keberangkatan_atlit</label>
                            <input type="date" name="jadwal_keberangkatan_atlit" id="jadwal_keberangkatan_atlit" class="form-control" required="true">
                            <p class="text-danger" id="err_jadwal_keberangkatan_atlit"></p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>jadwal_kepulangan_atlit</label>
                            <input type="date" name="jadwal_kepulangan_atlit" id="jadwal_kepulangan_atlit" class="form-control" required="true">
                            <p class="text-danger" id="err_jadwal_kepulangan_atlit"></p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>EMERGENCY</label>
                            <input type="text" name="Emergency" id="Emergency" class="form-control" required="true">
                            <p class="text-danger" id="err_Emergency"></p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Timeline_keseluruhan_aktifitas_pic_aktifitas</label>
                            <input type="date" name="Timeline_keseluruhan_aktifitas_pic_aktifitas" id="Timeline_keseluruhan_aktifitas_pic_aktifitas" class="form-control" required="true">
                            <p class="text-danger" id="err_Timeline_keseluruhan_aktifitas_pic_aktifitas"></p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Jadwal_final</label>
                            <input type="date" name="Jadwal_final" id="Jadwal_final" class="form-control" required="true">
                            <p class="text-danger" id="err_Jadwal_final"></p>
                        </div>
                    </div>
                    <button type="submit" name="simpan" id="simpan" class="btn btn-primary">
                        <i class="fa fa-save"></i> Simpan
                    </button>
            </form>
            <hr>
            <div class="data"></div>
        </div>
        <div class="text-center">© <?php echo date('d/m/Y'); ?> Copyright
            @endsection

            <!-- NOTE: tinggal atur lagi aja css nya ya , biar engga ketabrak hehehe -->