@section('css')

@stop

@section('js')

@stop

@extends('layouts.app')


@section('content')

<section class="content-header">
  <h1>
    Atlet - HALAMAN KE DUA
  </h1>
</section>

@endsection