@extends('layouts.app')
@section('isimain')
<style>
    .foto_ktp {
        border-radius: 5px;
        width: 80px;
        height: 50px;
    }
</style>
<section class="content">
    <a href="{{url ('/Data-Atlet/tambah')}}" class="btn btn-success" data-toggle="modal"><i class="fa fa-plus"></i><span> Add New Data </span></a>
    <a href="#" class="btn btn-warning" data-toggle="modal"><i class="fa fa-filter"></i><span> Filter Data By column</span></a>

    <div class="table-container">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Nomer Telepon</th>
                    <th>Jenis kelamin</th>
                    <th>foto ktp</th>
                    <th>nomer ktp</th>
                    <th>Alamat</th>
                    <th>nama cabor</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($atlet as $key=>$row)
                <tr>
                    <td>{{$row->id}}</td>
                    <td>{{$row->Nama}}</td>
                    <td>{{$row->Nomer_Telepon}}</td>
                    <td>{{$row->Jenis_kelamin}}</td>
                    <td><img class="foto_ktp" src="{{ asset('picture/'.$row->foto_ktp) }}" /></td>
                    <td>{{$row->nomer_ktp}}</td>
                    <td>{{$row->Alamat}}</td>
                    <td>{{$row->nama_cabor}}</td>
                    <td>{{$row->email}}</td>
                    <td>
                        <a href="{{url ('/Data-Atlet/edit/'.$row->id)}}">
                            <button type="edit" class="btn btn-primary btn-md dt-edit">
                                <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                            </button>
                        </a>
                        <a href="{{url ('/Data-Atlet/delete/'.$row->id)}}">
                            <button type="delete" class="btn btn-danger btn-md dt-delete">
                                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                            </button>
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="text-center">© <?php echo date('d/m/Y'); ?> Copyright:</div>

</section>

<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable();
    });
</script>
<script>
    $(document).ready(function() {
        $('a.more').click(function() {
            // Toggle Class
            $tr = $(this).parent().parent();
            $tr.toggleClass('expanded');
            // Tampilkan - sembunyikan baris
            $i = $(this).children('i');
            $i.removeClass('fa-chevron-down', 'fa-chevron-up');
            var arrow = $tr.hasClass('expanded') ? 'fa-chevron-up' : 'fa-chevron-down';
            $i.addClass(arrow);
            return false;
        });
    })
</script>
<script>
    @endsection