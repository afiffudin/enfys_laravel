@extends('edit')
@section('main')
<form action="/Data-monitoring-koni/edit" method="post">
    {{csrf_field()}}
    <div class="form-group">
        <label for="jadwal_keberangkatan_atlit">jadwal_keberangkatan_atlit </label>
        <input class="form-control @error('jadwal_keberangkatan_atlit') is-invalid @enderror" type="date" name="jadwal_keberangkatan_atlit" id="jadwal_keberangkatan_atlit" value="{{ old('jadwal_keberangkatan_atlit') }}"> @error('jadwal_keberangkatan_atlit')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <label for="jadwal_kepulangan_atlit">jadwal_kepulangan_atlit</label>
        <input class="form-control @error('jadwal_kepulangan_atlit') is-invalid @enderror" type="date" name="jadwal_kepulangan_atlit" id="jadwal_kepulangan_atlit" value="{{ old('jadwal_kepulangan_atlit') }}"> @error('jadwal_kepulangan_atlit')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <label for="Emergency">Emergency</label>
        <input class="form-control @error('Emergency') is-invalid @enderror" type="text" name="Emergency" id="Emergency" value="{{ old('Emergency') }}"> @error('Emergency')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <label for="Timeline_keseluruhan_aktifitas_pic_aktifitas">Timeline_keseluruhan_aktifitas_pic_aktifitas</label>
        <input class="form-control @error('Timeline_keseluruhan_aktifitas_pic_aktifitas') is-invalid @enderror" type="date" name="Timeline_keseluruhan_aktifitas_pic_aktifitas" id="Timeline_keseluruhan_aktifitas_pic_aktifitas" value="{{ old('Timeline_keseluruhan_aktifitas_pic_aktifitas') }}"> @error('Timeline_keseluruhan_aktifitas_pic_aktifitas')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <label for="Jadwal_final">Jadwal_final</label>
        <input class="form-control @error('Jadwal_final') is-invalid @enderror" type="date" name="Jadwal_final" id="Jadwal_final" value="{{ old('Jadwal_final') }}"> @error('Jadwal_final')
        <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group float-right">
        <button class="btn btn-lg btn-danger" type="reset">Reset</button>
        <button class="btn btn-lg btn-primary" type="submit">Submit</button>
    </div>
</form>