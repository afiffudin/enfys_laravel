@extends('layouts.app')
@section('css')
@show
@section('content')
<!--head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" href="">
    <title>data master nomer ketua koni</title>
    <!- Bootstrap ->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css" rel="stylesheet">
    <!- Font Awesome ->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <!- Datatable ->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
</head-->

<body>

    @section('judulmain','konimain')
    <!-- ini untuk judul page nya , bisa di modifikasi -->
    @section('isimain')
    <!-- ini untuk isi content atlet nya , sampai endsection ya -->

    <nav class="navbar navbar-dark bg-primary">
        SELAMAT DATANG DI DATA MASTER NOMER KETUA KONI
        </a>
    </nav>

    <div class="container">
        <h2 align="center" style="margin: 30px;"> DATA MASTER NOMER KETUA KONI </h2>
        <form class="form-data" id="form-data" action="/ketiga/add" method="post">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="hidden" name="id" id="id">
                        <input type="text" name="Nama" id="Nama" class="form-control" required="true">
                        <p class="text-danger" id="err_Nama"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label>Nomer_Telepon</label>
                        <input type="text" name="Nomer_Telepon" id="Nomer_Telepon" class="form-control" required="true">
                        <p class="text-danger" id="err_Nomer_Telepon"></p>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <button type="submit" name="simpan" id="simpan" class="btn btn-primary">
                            <i class="fa fa-save"></i> Simpan
                        </button>
                    </div>
        </form>
        <hr>

        <div class="data"></div>

    </div>


    </div>

    <div class="text-center">© <?php echo date('d/m/Y'); ?> Copyright:

        @endsection

        <!-- NOTE: tinggal atur lagi aja css nya ya , biar engga ketabrak hehehe -->