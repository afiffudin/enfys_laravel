<?php

namespace App\Http\Controllers;

use App\atlit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AtletAddkoniController extends Controller
{
    public function create(Request $request)
    {
        DB::table('data_master_nomer_ketua_koni')->insert([
            'Nama' => $request->nama,
            'Nomer_Telepon' => $request->Nomer_Telepon
        ]);
        return redirect('/ketuakoni');
    }
    public function index()
    {
        $atlet = DB::table('data_master_nomer_ketua_koni')->get();
        return view('data', compact('data'));
    }
}
